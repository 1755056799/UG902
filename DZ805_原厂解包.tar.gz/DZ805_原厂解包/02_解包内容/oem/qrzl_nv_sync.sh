#!/bin/sh

# 用于标记脚本是否已经执行过
COUNT=1

# 通过标记变量，确保脚本只执行一次
if [ "$COUNT" = 0 ]; then
    # 检查配置文件是否存在
    if [ ! -f "/mnt/oem/etc/qrzl_parameter_config" ]; then
        echo "Configuration file /mnt/oem/etc/qrzl_parameter_config not found"
        return 1
    fi

    echo "Syncing key-value pairs from /mnt/oem/etc/qrzl_parameter_config to nvram"

    # 逐行读取配置文件
    while IFS= read -r line || [ -n "$line" ]; do
        # 跳过注释行和空行
        case "$line" in
            \#*|"") continue ;;
        esac

        # 提取键值对
        key=$(echo "$line" | cut -d'=' -f1 | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')
        value=$(echo "$line" | cut -d'=' -f2- | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')

        # 检查是否为有效的键值对
        if [ -n "$key" ] && [ -n "$line" ]; then
            # 使用nv set将键值对保存到缓存中
            nv set "$key=$value"
            echo "Set nvram key '$key' with value '$value'"
        fi
    done < "/mnt/oem/etc/qrzl_parameter_config"

    echo "Finished syncing all key-value pairs"
    sed -i '4c\COUNT=1' "$0"
fi

